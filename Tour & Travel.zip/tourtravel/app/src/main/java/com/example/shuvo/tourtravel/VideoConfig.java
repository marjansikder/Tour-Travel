package com.example.shuvo.tourtravel;

public class VideoConfig {

   VideoConfig()
   { }
    public static final String API_KEY = "AIzaSyBqGp0df38GsMtKRFuyq6GtjWLFGrwzdHs" ;
}
